#https://orfe.princeton.edu/~jqfan/fan/classes/525.html
###  Transformed data 
DATA=read.csv("C:\\DataEcoFan\\Example1\\Macro201901transformed.csv", header=FALSE); names(DATA)=NULL
#DATA=DATA[601:706,-1]  ##  After  Crisis
DATA=DATA[1:576,-1]     ##  Before Crisis

Data=t(DATA)
#cov(Data)
###  removing outliers
#ddee=NULL
#for (j in 1:length(Data[,1])) {ddee=c(ddee,which(abs(Data[j,]-median(Data[j,]))>10*IQR(Data[j,])))}
#Data=Data[,-ddee]


pZ<-length(Data[,1]);     N=pZ             #dimension
n<-length(Data[1,]);      T=n              #sample size
rmax<-9
v<-rep(0, rmax); bpn<-(pZ+n)/(pZ*n); cpn<-min(pZ,n)
kfactor<-1:rmax
y00=pZ/(n-1)




hm1=hm2=hm3<-matrix(rep(0,N*rmax),N,rmax)
for(i in 1:rmax){ for(j in i:N){ hm1[j,i]<-1 } }		

for(i in 1:rmax){ for(j in (i+1):N){ hm2[j,i]<-1} }

for(i in 1:rmax){ for(j in (i+2):N){ hm3[j,i]<-1 } }






denote0=rep(0,13)
X=Data-matrix(rep(t(apply(Data,1,mean)),n),ncol=n)

  ## Method 1: the method of zheng: denote0[,13]
  sn<-cov(t(X)); hatRR=cov2cor(sn); lambdaZ<-eigen(hatRR)$values; DD=NULL; lambdaLY=lambdaZ; p=pZ
  pp=min(n-2,p-2); mz=rep(0,pp); dmz=mz; tmz=mz
 
      for (kk in 1:pp){qu=3/4
      lambdaZ1=lambdaZ[-seq(max(0, 1),kk,1)]; z0=qu*lambdaZ[kk]+(1-qu)*lambdaZ[kk+1]
      ttt=c(lambdaZ1-lambdaZ[kk], z0-lambdaZ[kk]);  
      y0=(length(lambdaZ1))/(n)
      mz[kk]=-(1-y0)/z0+y0*mean(na.omit(1/ttt))
                      }
  temp2018=(-1/mz)[-1]-1-sqrt(pZ/(n-1)); temp1=seq(1,rmax,1); temp2=cbind(temp1, temp2018[1:rmax])
  k00new=max((temp2[,1][temp2[,2]>0]), 0)+1
  
  denote0[13]=k00new 
  

  ## Method 2: PC1, PC2, PC3, IC1, IC2, IC3  
  v<-rep(0,rmax)
  kfactor<-1:rmax
  bNT<-(N+T)/(N*T)
  cNT<-min(N,T)
  bev<-eigen((X%*%t(X))/T)$values
  for(k in 1:rmax){ v[k]<-sum(bev[(k+1):N]) }
  
  PC1<-v-v[rmax]*bNT*log(bNT)*kfactor
  PC2<-v+v[rmax]*bNT*log(cNT)*kfactor
  PC3<-v+v[rmax]*log(cNT)/cNT*kfactor
  
  IC1<-log(v)-bNT*log(bNT)*kfactor
  IC2<-log(v)+bNT*log(cNT)*kfactor
  IC3<-log(v)+log(cNT)/cNT*kfactor
  
  PC1f<-which.min(PC1); denote0[1]=PC1f
  PC2f<-which.min(PC2); denote0[2]=PC2f
  PC3f<-which.min(PC3); denote0[3]=PC3f
  
  IC1f<-which.min(IC1); denote0[4]=IC1f
  IC2f<-which.min(IC2); denote0[5]=IC2f
  IC3f<-which.min(IC3); denote0[6]=IC3f
  

  ## Method 3: the method of onatski
  oev<-eigen((X%*%t(X))/T)$values
  ow<-2^(2/3)/(2^(2/3)-1)
  #	ormax<-1.55*min(N^(2/5),T^(2/5))	
  delte1<-max(N^(-1/2),T^(-1/2))
  delte2<-0
  delte3<-max(N^(-2/3),T^(-2/3))
  ou<-ow*oev[rmax+1]+(1-ow)*oev[2*rmax+1]
  ON1f<-sum(ifelse(oev>(1+delte1)*ou,1,0)); denote0[7]=ON1f
  ON2f<-sum(ifelse(oev>(1+delte2)*ou,1,0)); denote0[8]=ON2f
  ON3f<-sum(ifelse(oev>(1+delte3)*ou,1,0)); denote0[9]=ON3f
  
  ## Method 4: the method of onatski2
  nols<-4
  noev<-eigen((X%*%t(X))/T)$values
  oJ<-rep(1,(nols+1))
  ed<-noev[1:rmax]-noev[2:(rmax+1)]
  noj<-rmax+1
  for(j in 1:4){
    noy<-noev[noj:(noj+nols)]
    nox<-(noj+seq(-1,(nols-1),1))^(2/3)
    nobeta<-sum((nox-mean(nox))*(noy-mean(noy)))/sum((nox-mean(nox))^2)
    nodelte<-2*abs(nobeta)
    noer<-ifelse(max(ed-nodelte)<0,0,max(which(ed>=nodelte)))
    noj<-noer+1
  }
  NONf<-noer; denote0[10]=NONf
  
  ## Method 5: the method of horenstein
  hev<-eigen((X%*%t(X))/(T*N))$values
  er1<-hev[1:rmax]
  er2<-hev[2:(rmax+1)]
  gr1<-hev%*%hm1
  gr2<-hev%*%hm2
  gr3<-hev%*%hm3
  er<-er1/er2
  gr<-log(gr1/gr2)/log(gr2/gr3)
  ERf<-which.max(er); denote0[11]=ERf
  GRf<-which.max(gr); denote0[12]=GRf
  
  print(denote0[c(2,13)])
  sort(diag(sn))

  NF=denote0[13]
  max(NF, PC2f)
###  largest eigenvalues of sample covariance matrix  and contribution rate
  bev[1:max(NF, PC2f)]; 
  sum(bev[1:NF])/sum(bev)
  sum(bev[1:PC2f])/sum(bev)

###  largest eigenvalues of sample correlation matrix and contribution rate
  lambdaZ[1:max(NF, PC2f)];
  sum(lambdaZ[1:NF])/sum(lambdaZ)
  sum(lambdaZ[1:PC2f])/sum(lambdaZ)
  
  
 #plot(seq(1,p,1), sqrt(diag(sn)), ylab=" ", xlab=expression(j), type="n", cex.lab=2.2, cex.axis=2.5)
 #points(seq(1,p,1), sqrt(diag(sn)), col=6, cex=2)
 #title(ylab=expression(sqrt(sigma[jj])), cex.lab=3, line=1.0)

