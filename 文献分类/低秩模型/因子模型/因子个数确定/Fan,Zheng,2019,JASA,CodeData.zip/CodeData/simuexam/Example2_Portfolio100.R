#http://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html

#### After Crisis
####  I have used the daily returns of 100 industrial portfolios formed on the basis of size and book-to-market ratio from 
#the website of Kenneth French from January 4, 2010 to April 30, 2019 for the factor analysis. 
num=seq(1,2346,1)
DATA1=read.csv("C:\\DataEcoFan\\Example2\\AfterCrisis\\20102019AverageValueWeightedReturns.csv", header=FALSE)
DATA2=read.csv("C:\\DataEcoFan\\Example2\\AfterCrisis\\ThreeFactorsDaily.csv", header=FALSE)
DATA0=read.csv("C:\\DataEcoFan\\Example2\\AfterCrisis\\MOMFactorDaily.csv", header=FALSE)
TIME=DATA2[,1]

#### Before Crisis
####  I have used the daily returns of 100 industrial portfolios formed on the basis of size and book-to-market ratio from 
#the website of Kenneth French from January 2, 1998 to December 31, 2007 for the factor analysis. 
#num=seq(1,2514,1)
#DATA1=read.csv("C:\\DataEcoFan\\Example2\\BeforeCrisis\\100PortfolioDaily.csv", header=FALSE)
#DATA2=read.csv("C:\\DataEcoFan\\Example2\\BeforeCrisis\\ThreeFactorsDaily.csv", header=FALSE)
#DATA0=read.csv("C:\\DataEcoFan\\Example2\\BeforeCrisis\\MOMFactorDaily.csv", header=FALSE)
#TIME=DATA2[,1]

data00=NULL; LL=1; nn=NULL
for (i in 1:length(DATA0[,1])) {if (DATA0[i,1]==DATA1[LL,1]) {LL=LL+1; nn=c(nn,i)}}

DATA1=DATA1[,-1]; 
DATA2=DATA2[,-c(1, 5)]; FACTORS=cbind(DATA2, DATA0[nn,2])  ##  four factors                   



Data=t(DATA1)              ##  including all features


pZ<-length(Data[,1]);     N=pZ             #dimension
n<-length(Data[1,]);      T=n              #sample size
rmax<-10
v<-rep(0, rmax); bpn<-(pZ+n)/(pZ*n); cpn<-min(pZ,n)
kfactor<-1:rmax
y00=pZ/(n-1)

hm1=hm2=hm3<-matrix(rep(0,N*rmax),N,rmax)
for(i in 1:rmax){ for(j in i:N){ hm1[j,i]<-1 } }		
for(i in 1:rmax){ for(j in (i+1):N){ hm2[j,i]<-1} }
for(i in 1:rmax){ for(j in (i+2):N){ hm3[j,i]<-1 } }

denote0=rep(0,13)
X=Data-matrix(rep(t(apply(Data,1,mean)),n),ncol=n)



  ## Method 1: the method of zheng: denote0[,13]
  sn<-cov(t(X)); hatRR=cov2cor(sn); lambdaZ=eigen(hatRR)$values; VectorZ=eigen(hatRR)$vectors
  DD=NULL; lambdaLY=lambdaZ; p=pZ
  pp=rmax+2; mz=rep(0,pp); dmz=mz; tmz=mz
 
      for (kk in 1:pp){qu=3/4
      lambdaZ1=lambdaZ[-seq(max(0, 1),kk,1)]; z0=qu*lambdaZ[kk]+(1-qu)*lambdaZ[kk+1]
      ttt=c(lambdaZ1-lambdaZ[kk], z0-lambdaZ[kk]) 
      y0=(length(lambdaZ1))/(n-1)
      mz[kk]=-(1-y0)/z0+y0*mean(na.omit(1/ttt))
                      }
  temp2018=(-1/mz)[-1]-1-sqrt(pZ/(n-1)); temp1=seq(1,rmax,1); temp2=cbind(temp1, temp2018[1:rmax])
  k00new=max((temp2[,1][temp2[,2]>0]), 0)+1
  denote0[13]=k00new 
  

  ## Method 2: PC1, PC2, PC3, IC1, IC2, IC3  
  v<-rep(0,rmax)
  kfactor<-1:rmax
  bNT<-(N+T)/(N*T)
  cNT<-min(N,T)
  bev<-eigen((X%*%t(X))/T)$values
  for(k in 1:rmax){
    v[k]<-sum(bev[(k+1):N])
  }
  
  PC1<-v-v[rmax]*bNT*log(bNT)*kfactor
  PC2<-v+v[rmax]*bNT*log(cNT)*kfactor
  PC3<-v+v[rmax]*log(cNT)/cNT*kfactor
  
  IC1<-log(v)-bNT*log(bNT)*kfactor
  IC2<-log(v)+bNT*log(cNT)*kfactor
  IC3<-log(v)+log(cNT)/cNT*kfactor
  
  PC1f<-which.min(PC1); denote0[1]=PC1f
  PC2f<-which.min(PC2); denote0[2]=PC2f
  PC3f<-which.min(PC3); denote0[3]=PC3f
  
  IC1f<-which.min(IC1); denote0[4]=IC1f
  IC2f<-which.min(IC2); denote0[5]=IC2f
  IC3f<-which.min(IC3); denote0[6]=IC3f
  

  ## Method 3: the method of onatski
  oev<-eigen((X%*%t(X))/T)$values
  ow<-2^(2/3)/(2^(2/3)-1)
  #	ormax<-1.55*min(N^(2/5),T^(2/5))	
  delte1<-max(N^(-1/2),T^(-1/2))
  delte2<-0
  delte3<-max(N^(-2/3),T^(-2/3))
  ou<-ow*oev[rmax+1]+(1-ow)*oev[2*rmax+1]
  ON1f<-sum(ifelse(oev>(1+delte1)*ou,1,0)); denote0[7]=ON1f
  ON2f<-sum(ifelse(oev>(1+delte2)*ou,1,0)); denote0[8]=ON2f
  ON3f<-sum(ifelse(oev>(1+delte3)*ou,1,0)); denote0[9]=ON3f
  
  ## Method 4: the method of onatski2
  nols<-4
  noev<-eigen((X%*%t(X))/T)$values
  oJ<-rep(1,(nols+1))
  ed<-noev[1:rmax]-noev[2:(rmax+1)]
  noj<-rmax+1
  for(j in 1:4){
    noy<-noev[noj:(noj+nols)]
    nox<-(noj+seq(-1,(nols-1),1))^(2/3)
    nobeta<-sum((nox-mean(nox))*(noy-mean(noy)))/sum((nox-mean(nox))^2)
    nodelte<-2*abs(nobeta)
    noer<-ifelse(max(ed-nodelte)<0,0,max(which(ed>=nodelte)))
    noj<-noer+1
  }
  NONf<-noer; denote0[10]=NONf
  
  ## Method 5: the method of horenstein
  hev<-eigen((X%*%t(X))/(T*N))$values
  er1<-hev[1:rmax]
  er2<-hev[2:(rmax+1)]
  gr1<-hev%*%hm1
  gr2<-hev%*%hm2
  gr3<-hev%*%hm3
  er<-er1/er2
  gr<-log(gr1/gr2)/log(gr2/gr3)
  ERf<-which.max(er); denote0[11]=ERf
  GRf<-which.max(gr); denote0[12]=GRf
 
  ##  number of selected factors by $PC_3$, $IC_3$, $ON_2$, $ER$ and $GR$ and $ACT$ 
  LS=c(2,3,6,8,11,12,13) 
  print(denote0[LS])
  
# plot(seq(1,p,1), sqrt(diag(sn)), xlab=expression(sigma[jj]), ylab=expression(j), pch=17, col=2, col.lab=1, font.axis=2)

###### R^2 by using sample correlation matrix
#### Row 1 in Table 6: Observable factors regression on 4 selected factors
NF=denote0[13]
PRINCI=princomp(t(Data), cor=TRUE)$scores[,1:NF]
# (1) Observable factor Rm-Rf regression on NF=4 selected factors
yy=FACTORS[,1]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared
plot(yy, fitted(lmS), xlab="Rm-Rf", ylab="", cex.lab=3, cex.axis=1.8, col=6)
FV=c("Fitted values")
title(ylab="Fitted values", cex.lab=3, line=2.2)
# (2) Observable factor SMB regression on NF=4 selected factors
yy=FACTORS[,2]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared
plot(yy, fitted(lmS), xlab="SMB", ylab="", cex.lab=3, cex.axis=1.8, col=6)
FV=c("Fitted values")
title(ylab="Fitted values", cex.lab=3, line=2.2)
# (3)Observable factor HML regression on NF=4 selected factors
yy=FACTORS[,3]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared
plot(yy, fitted(lmS), xlab="HML", ylab="", cex.lab=3, cex.axis=1.8, col=6)
FV=c("Fitted values")
title(ylab="Fitted values", cex.lab=3, line=2.2)
# (4)Observable factor Momentum regression on NF=4 selected factors
yy=FACTORS[,4]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared
plot(yy, fitted(lmS), xlab="Momentum", ylab="", cex.lab=3, cex.axis=1.8, col=6)
FV=c("Fitted values")
title(ylab="Fitted values", cex.lab=3, line=2.2)

#### Row 2 in Table 6: Observable factors regression on 3 selected factors
NF=3
PRINCI=princomp(t(Data), cor=TRUE)$scores[,1:NF]
# (1) Observable factor Rm-Rf regression on NF=3 selected factors
yy=FACTORS[,1]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared
# (2) Observable factor SMB regression on NF=3 selected factors
yy=FACTORS[,2]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared
# (3)Observable factor HML regression on NF=3 selected factors
yy=FACTORS[,3]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared
# (4)Observable factor Momentum regression on NF=3 selected factors
yy=FACTORS[,4]
lmS=lm(yy~PRINCI[,1:NF])
summary(lmS)$r.squared



######  R^2 by using sample covariance matrix 
#NF=denote0[13]
#PRINCI=princomp(t(Data), cor=FALSE)$scores[,1:NF]
#yy=FACTORS[,1]
#lmS=lm(yy~PRINCI[,1:NF])
#summary(lmS)$r.squared


#plot(num, yy, xlab="year/month/day", ylab="", type="n", xaxt="n", cex.lab=3, cex.axis=3)
#month=TIME[c(1,900, 1700, 2346)]
#axis(1,labels=month,at=num[c(1,900, 1700, 2514)],cex.axis=3)
#points(num, yy, col=1, pch=1)
#points(num, fitted(lmS), col=6, pch=2)
#temp <- legend(2200, 3, legend = c(" ", " "),
#               text.width = strwidth("1,000"),
#               pch=1:2, xjust = 1, yjust = 1,col=1:6, cex=2)
#text(temp$rect$left + temp$rect$w, temp$text$y,c("HML", "Fitted values"), pos=2, cex=2)


###  Computing \|P_A-\P_B\| by correlation matrix: 4 observable factors-4 selected factors
NF=denote0[13]
PRINCI=princomp(t(Data), cor=TRUE)$scores[,1:NF]
A=FACTORS[,1:NF]; B=PRINCI; names(A)=NULL; names(B)=NULL
A0=NULL; for (j in 1:NF) {A0=cbind(A0, A[,j])}; A=A0
PA=A%*%solve(t(A)%*%A)%*%t(A)
PB=B%*%solve(t(B)%*%B)%*%t(B)
PC=(PA-PB)%*%t(PA-PB)
norm2=sqrt(max(eigen(PC)$values))
normF=sqrt(sum(diag(PC)))
print(c(norm2, normF))

###  Computing \|P_A-\P_B\| by correlation matrix: 3 observable factors-3 selected factors
NF=3
PRINCI=princomp(t(Data), cor=TRUE)$scores[,1:NF]
A=FACTORS[,1:NF]; B=PRINCI; names(A)=NULL; names(B)=NULL
A0=NULL; for (j in 1:NF) {A0=cbind(A0, A[,j])}; A=A0
PA=A%*%solve(t(A)%*%A)%*%t(A)
PB=B%*%solve(t(B)%*%B)%*%t(B)
PC=(PA-PB)%*%t(PA-PB)
norm2=sqrt(max(eigen(PC)$values))
normF=sqrt(sum(diag(PC)))
print(c(norm2, normF))



NF=denote0[13]
   max(NF, PC2f)
###  largest eigenvalues of sample covariance matrix  and contribution rate
  bev[1:max(NF, PC2f)]; 
  sum(bev[1:NF])/sum(bev)
  sum(bev[1:max(NF, PC2f)])/sum(bev)

###  largest eigenvalues of sample correlation matrix and contribution rate
  lambdaZ[1:max(NF, PC2f)];
  sum(lambdaZ[1:NF])/sum(lambdaZ)
  sum(lambdaZ[1:max(NF, PC2f)])/sum(lambdaZ)
  
  
  




